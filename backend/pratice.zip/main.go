package main

import (
	"bufio"
	"fmt"
	"github.com/gin-gonic/gin"
	"os"
	//"regexp"
	"strconv"
	"strings"
)

var pathFile string = "./datafile/saving.csv"

// https://stackoverflow.com/a/55438264
type ResponseList struct {
	data [][]string
}

type ResponseCreate struct {
	FirstName string
	LastName string
	Address string
	Phone string
}

type MyArr struct {
	Items []ResponseCreate
}

func (box *MyArr) AddItem(item ResponseCreate) {
	box.Items = append(box.Items, item)
}

func check(e error, c *gin.Context) {
	if e != nil {
		c.JSON(400, gin.H{
			"response": 400,
			"message": "error",
		})
	}
}

func list(c *gin.Context) {
	// read file content https://stackoverflow.com/a/29559462
	iFile, err := os.Open(pathFile)
	check(err, c)
	scanner := bufio.NewScanner(bufio.NewReader(iFile))
	counter := 1
	box := MyArr{}
	for scanner.Scan() {
		counter++
		line := scanner.Text()
		str := strings.Split(line, ",")
		item := ResponseCreate{FirstName: str[1], LastName: str[2], Address: str[3], Phone: str[4],}
		box.AddItem(item)
	}

	defer iFile.Close()

	c.JSON(200, gin.H{
		"response": 200,
		"message": "success",
		"data": box.Items,
	})
}

func create(c *gin.Context) {
	firstname := c.PostForm("firstname")
	lastname := c.PostForm("lastname")
	address := c.PostForm("address")
	phone := c.PostForm("phone")

	// read file content https://stackoverflow.com/a/29559462
	iFile, err := os.Open(pathFile)
	check(err, c)

	scanner := bufio.NewScanner(bufio.NewReader(iFile))
	counter := 1
	for scanner.Scan() {
		counter++
	}
	counters := strconv.Itoa(counter)

	defer iFile.Close()

	// save data on file https://stackoverflow.com/a/7165157
	vile := counters+", "+firstname+", "+lastname+", "+address+", "+phone+"\n"
	fileR, err := os.OpenFile(pathFile, os.O_APPEND|os.O_WRONLY, 0644)
	check(err, c)

	n, err := fileR.WriteString(vile)
	check(err, c)

	defer fileR.Close()

	if(n == 0) {
		c.JSON(400, gin.H{
			"response": 400,
			"message": "error",
		})
	} else {
		c.JSON(200, gin.H{
			"response": 200,
			"message": "success",
		})
	}
}

func deleted(c *gin.Context) {
	//idRow := c.PostForm("id")
	// read file content https://stackoverflow.com/a/29559462
	iFile, err := os.Open(pathFile)
	check(err, c)

	reader := bufio.NewReader(iFile)

	for {
		pos,_ := iFile.Seek(0, 1)
		fmt.Println("Position in file is: %d", pos)
		bytes, _, _ := reader.ReadLine()

		if (len(bytes) == 0) {
		break
		}

		lineString := string(bytes)
		if(lineString == "two") {
             iFile.Seek(int64(-(len(lineString))), 1)
             file.WriteString("This is a test.")
         }

         fmt.Printf(lineString + "\n")
	}
	/*scanner := bufio.NewScanner(bufio.NewReader(iFile))
	counter := 1
	var line string
	for scanner.Scan() {
		counter++
		line = scanner.Text()
		str := strings.Split(line, ",")
		if(str[0] == idRow) {
			line = ""
			//re := regexp.MustCompile(line)
			//re.ReplaceAllString(line, "\u005c")
			//strings.Replace(line, line, "\u005c", 0)
		}
		fmt.Println(line)
	}*/

	defer iFile.Close()

	c.JSON(200, gin.H{
		"response": 200,
		"message": "success",
	})
}

func main() {
	router := gin.Default()
	router.GET("/list", list)
	router.POST("/create", create)
	router.POST("/delete", deleted)
	router.Run(":8181")
}
